#include<iostream>
using namespace std;
int main(){

    int secretNumber =65; 
    int guess;
    int attempts = 0;
    cout << "Welcome to the number guessing game!" << endl;
    while (true) {
        cout << "Enter your guess: ";
        cin >> guess;
        attempts++;
         if (guess < secretNumber) {
            cout << "Too low! Try again." << endl;
        } else if (guess > secretNumber) {
           cout << "Too high! Try again." << endl;
        } else {
            cout << "Congratulations! You found the number in " << attempts << " attempts." << endl;
         }
    }
  return 0;
}