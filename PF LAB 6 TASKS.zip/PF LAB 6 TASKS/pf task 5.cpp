#include<iostream>
using namespace std;
int main()
{
	int  n;
	int square;
	int sum=0;
	cout<<"Enter the number of your choice:";
	cin>>n ;
	
	for(int i=1 ; i<=n ;i++)
	{
		square=i*i;
		sum=sum+square;
	}
	cout<<"Sum of the squares of N natural number is =" <<sum;
	return 0;
}