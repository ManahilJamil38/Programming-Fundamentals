#include<iostream>
using namespace std;
int main()
{
	int i=0, j;
	do
	{
	j=1;
	do
		{
	cout<<i<<"*"<<j<<"="<<i*j<<endl;
	j++;
		}
	while( j<= 10 );
	i++;
	cout<<endl;
	}
	while( i<=5 );
	return 0;
}
