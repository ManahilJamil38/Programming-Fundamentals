#include<iostream>
using namespace std;
int main()
{
   int m=0, n;
   while( m<7 )
{
   int n=0;
   while( n<m )
{
   cout<<"*";
   n++;	
		}
    cout<<endl;
    m++;
	}
	return 0;
}