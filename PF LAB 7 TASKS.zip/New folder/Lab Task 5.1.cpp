#include<iostream>
using namespace std;
int main(){
	int i, j, temp, O_num, sum, digit;
	cout<<"Enter a number: ";
	cin>> temp;
	O_num = temp;
	for( i=0; temp!=0; i++ ){
		digit = temp % 10;
		for( j=1; j<=1; j++ ){
			sum += digit;
		}
		temp /= 10;
	}
	cout<<"Sum of the digits of "<<O_num<<" = "<<sum <<endl;
	return 0;
}

