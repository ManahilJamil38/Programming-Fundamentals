#include<iostream>
using namespace std;
int main()
{
	int i=0, j;
	do
	{
	j=0;
	do
		{
	cout<<"*";
	j++;
		}
	while( j< 9);
	i++;
	cout<<endl;
	}
	while(i<9);
	return 0;
}

